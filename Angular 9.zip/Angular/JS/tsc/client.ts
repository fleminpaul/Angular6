import {Person} from './person'

let p = new Person("FLemin",32)
console.log(`${p.getName()},${p.getAge()}`);