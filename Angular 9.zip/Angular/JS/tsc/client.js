"use strict";
exports.__esModule = true;
var person_1 = require("./person");
var p = new person_1.Person("FLemin", 32);
console.log(p.getName() + "," + p.getAge());
