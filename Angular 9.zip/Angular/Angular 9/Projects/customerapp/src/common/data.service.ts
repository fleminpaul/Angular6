import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './customer';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private customerURL:string= 'http://localhost:3000/customers';
  private ordersURL:string= 'http://localhost:3000/orders';
  constructor(private http:HttpClient) { 
    
  }
  getCustomers():Observable<Customer[]>
  {
    return this.http.get<Customer[]>(this.customerURL);
  }
  getCustomer(id:number):Observable<Customer>
  {
    return this.http.get<Customer>(`${this.customerURL}/${id}`);
  }
  addCustomer(customer:Customer):Observable<any>{
    return this.http.post(this.customerURL,customer)
  }

  updateCustomer(customer:Customer):Observable<any>{
    return this.http.put(`${this.customerURL}/${customer.id}`,customer)
  }

  deleteCustomer(id:number):Observable<any>{
    return this.http.delete(`${this.customerURL}/${id}`)
  }
}
