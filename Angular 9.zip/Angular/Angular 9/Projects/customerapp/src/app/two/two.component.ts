import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/common/shared.service';

@Component({
  selector: 'app-two',
  templateUrl: './two.component.html',
  styleUrls: ['./two.component.css']
})
export class TwoComponent implements OnInit {

  constructor(private shared:SharedService) { }

  ngOnInit(): void {
    // let i=0;
    // setInterval(()=>{
    //   this.shared.addData(++i);
    // },1000)
  }
  doTask() {
    console.log("Do Task from TWO")
  }
}
