import { Component, OnInit, ViewChild } from '@angular/core';
import { TwoComponent } from '../two/two.component';

@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrls: ['./one.component.css']
})
export class OneComponent implements OnInit {

@ViewChild(TwoComponent)
two:TwoComponent;

  constructor() { }

  ngOnInit(): void {
  }

  invoke(){
    this.two.doTask()
  }
}
