import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/common/customer';
import { DataService } from 'src/common/data.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  data: Customer[] = [];

  mainCustomers: Customer[] = [];
  searchText: string = "";
  mode:string="card";

  constructor(private dataservice:DataService) { }

  ngOnInit(): void {
     this.getCustomers();
  }

  getCustomers(){
    this.dataservice.getCustomers().subscribe(result=>{
      this.data=result;
      this.mainCustomers= this.data;
     }); 
  }
//if data is not displaying check LinkActivate Guard code in link.activate.ts
  deleteCustomer(customer: Customer) {
    //this.data= this.mainCustomers=this.mainCustomers.filter(cust=>cust.id!=customer.id);
    this.dataservice.deleteCustomer(customer.id).subscribe(result=>{
      console.log(`${customer.id}:${customer.firstName}_${customer.lastName} deleted`)
      this.getCustomers();
    });
    this.searchText="";
  }

  filterCustomers() {
    this.data = this.mainCustomers.filter(customer => {
      return (
        (customer.firstName.toUpperCase().indexOf(this.searchText.toUpperCase()) >= 0) ||
        (customer.lastName.toUpperCase().indexOf(this.searchText.toUpperCase()) >= 0)
      )
    })
  }

  ChangeMode(mode:string){
    this.mode=mode;
  }
}
