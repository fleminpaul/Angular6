import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Customer } from 'src/common/customer';

@Component({
  selector: 'app-customer-card',
  templateUrl: './customer-card.component.html',
  styleUrls: ['./customer-card.component.css']
})
export class CustomerCardComponent implements OnInit {

  @Input()
  customers:Customer[];

  @Output()
  onDelete:EventEmitter<Customer>=new EventEmitter<Customer>();
 
  constructor() { }

  ngOnInit(): void {
  }

  deleteCustomer(customer:Customer)
  {
   this.onDelete.next(customer);
  }
}
