import { NgModule } from '@angular/core';

import { RouterModule, Route } from '@angular/router'
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { CustomersComponent } from './customer/customers/customers.component';
import { CustomerCardComponent } from './customer/customer-card/customer-card.component';
import { CustomerListComponent } from './customer/customer-list/customer-list.component';
import { HomeComponent } from './home/home.component';
import { LinkActivate } from './link.activate';
import { CustomerEditComponent } from './customer/customer-edit/customer-edit.component';
import { DataService } from 'src/common/data.service';
import { OneComponent } from './one/one.component';
import { TwoComponent } from './two/two.component';
import { ThreeComponent } from './three/three.component';
import { HoverDirective } from './hover.directive';

const route: Route[] = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'customers',
    component: CustomersComponent,
    canActivate: [LinkActivate]
  },
  {
    path: 'customers/edit/:id',
    component: CustomerEditComponent
  },
  {
    path: 'orders',
    loadChildren: () => import('./orders/orders.module').then(m => m.OrdersModule)
  },

  {
    path: '**',
    component: HomeComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    CustomersComponent,
    CustomerCardComponent,
    CustomerListComponent,
    HomeComponent,
    CustomerEditComponent,
    OneComponent,
    TwoComponent,
    ThreeComponent,
    HoverDirective,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(route)
  ],
  providers: [LinkActivate, DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
