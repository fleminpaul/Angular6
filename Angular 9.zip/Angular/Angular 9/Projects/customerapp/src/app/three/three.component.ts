import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/common/shared.service';

@Component({
  selector: 'app-three',
  templateUrl: './three.component.html',
  styleUrls: ['./three.component.css']
})
export class ThreeComponent implements OnInit {

  constructor(private shared: SharedService) { }
  data: any[]=[];
  ngOnInit(): void {
    this.shared.getSubject().subscribe(r => {
      this.data = r;
    })
  }


}
