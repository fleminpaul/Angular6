import {Student} from './Student';
let students:Student[]=[
    new Student("Flemin",31),
    new Student("Bob",23)
]

export default students;