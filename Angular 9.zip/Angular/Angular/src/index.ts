import students from './Store'
students.forEach(stud=>{
    console.log(`${stud.getName()}:${stud.getAge()}:${stud["subject"]}`)
})