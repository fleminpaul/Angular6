import { PipeTransform, Pipe } from "@angular/core";

@Pipe({
    name: "convert"
})
export class Upper implements PipeTransform {
    transform(value: any, ...args: any[]) {
        if(args[0] === 'upper') {
        return value.toUpperCase();
         }
    }
    
}

// {{customer.firstName | convert:upper}}