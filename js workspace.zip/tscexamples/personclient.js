"use strict";
exports.__esModule = true;
var Persons_1 = require("./Persons");
var p = new Persons_1.Person("A", 33);
console.log(p.getName(), p.getAge());
