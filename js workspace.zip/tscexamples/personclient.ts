import {Person} from './Persons';

let p = new Person("A", 33);

console.log(p.getName(), p.getAge());

 



