import {Student} from './Students';

let students:Student[] = [
    new Student("a",22),
    new Student("b", 31),
    new Student("c", 20)
];

export default students;


