"use strict";
exports.__esModule = true;
var Students_1 = require("./Students");
var students = [
    new Students_1.Student("a", 22),
    new Students_1.Student("b", 31),
    new Students_1.Student("c", 20)
];
exports["default"] = students;
