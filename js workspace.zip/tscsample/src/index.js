"use strict";
exports.__esModule = true;
var Store_1 = require("./Store");
Store_1["default"].forEach(function (s) {
    console.log(s.getName(), s.getAge(), s["subject"]);
});
