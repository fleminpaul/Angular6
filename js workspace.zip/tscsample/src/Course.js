"use strict";
exports.__esModule = true;
function Course(config) {
    return function (target) {
        Object.defineProperty(target.prototype, "subject", {
            "value": config.name
        });
    };
}
exports.Course = Course;
