function forEach(elems, action) {
    for(var i = 0; i < elems.length; i++) {
        action(elems[i]);
    }
}

function filter(elems, predicate) {
    var result = [];
    forEach(elems, function(elem){
        if(predicate(elem)){
            result.push(elem);
        }
    });

    return result;
}

// mapperFn transforms
function map(elems, mapperFn) {
    var result = [];
    forEach(elems, function(elem){
          result.push(mapperFn(elem));
    });
    return result;
}